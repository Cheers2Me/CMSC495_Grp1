package com.example.group1todoapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Group1TodoApplicationTests {

	@Test
	void contextLoads() {
	}

}
