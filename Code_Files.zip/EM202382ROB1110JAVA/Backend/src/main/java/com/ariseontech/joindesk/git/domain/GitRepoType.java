package com.ariseontech.joindesk.git.domain;

public enum GitRepoType {
    GITHUB,
    GITLAB
}
