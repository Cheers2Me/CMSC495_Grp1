package com.ariseontech.joindesk.auth.service;

public class LoginDetail {
}
