package com.ariseontech.joindesk.issues.domain;

public enum WorkflowTransitionPropertyTypes {
    CONDITION,
    POST_FUNCTION
}
