package com.ariseontech.joindesk.issues.domain;

public enum IssueLifeCycle {

    TODO, INPROGRESS, DONE, REVIEW, ALERT, HIGHLIGHT

}
