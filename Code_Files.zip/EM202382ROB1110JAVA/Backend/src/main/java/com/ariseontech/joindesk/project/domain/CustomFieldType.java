package com.ariseontech.joindesk.project.domain;

public enum CustomFieldType {
    TEXT,
    NUMBER,
    DATE,
    SELECT,
    USER,
    VERSION
}
