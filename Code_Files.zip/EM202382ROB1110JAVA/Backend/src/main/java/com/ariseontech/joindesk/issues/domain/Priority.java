package com.ariseontech.joindesk.issues.domain;

public enum Priority {

    Urgent, High, Normal, Low

}
