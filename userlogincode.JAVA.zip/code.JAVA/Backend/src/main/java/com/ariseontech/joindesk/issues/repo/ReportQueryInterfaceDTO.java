package com.ariseontech.joindesk.issues.repo;

public interface ReportQueryInterfaceDTO {
    String getKey();

    Long getStatus();

    Long getCnt();
}
