package com.ariseontech.joindesk.webhook.domain;

public enum WebHookRequestType {
    GET,
    POST
}
