package com.example.group1todoapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Group1TodoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Group1TodoApplication.class, args);
	}

}
