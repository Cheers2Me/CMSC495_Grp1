package com.ariseontech.joindesk.auth.domain;

public enum PreferredAuthTypes {
    EMAIL,
    SLACK,
    MFA
}
