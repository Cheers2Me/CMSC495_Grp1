export class WebHookHeaders {

    public id: number;
    public key = '';
    public value = '';

    constructor(public edit = false) {
    }
}
